#!/usr/bin/env python3
import rospy
import math
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped, Twist
from final_one.srv import CommandVel, CommandVelResponse
import socket
import struct
import tf

class PathExecutor:
    def __init__(self):
        rospy.init_node('lite3_path_executor')

        # UDP Configuration (from your working setup)
        self.UDP_IP = rospy.get_param("~ip", "192.168.1.120")
        self.UDP_PORT = rospy.get_param("~port", 43893)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Controller Parameters
        self.lookahead_distance = 0.3  # meters
        self.max_linear_speed = 0.5    # m/s
        self.max_angular_speed = 1.3   # rad/s
        self.cmd_frequency = 20.0      # Hz

        # TF Listener for robot pose
        self.tf_listener = tf.TransformListener()
        self.robot_frame = rospy.get_param("~robot_frame", "base_link")
        self.world_frame = rospy.get_param("~world_frame", "map")

        # Path following
        self.current_path = None
        self.path_sub = rospy.Subscriber(
            '/move_base/TrajectoryPlannerROS/global_plan',
            Path,
            self.path_callback,
            queue_size=1
        )

        # Control timer
        self.control_timer = rospy.Timer(
            rospy.Duration(1.0/self.cmd_frequency),
            self.control_loop
        )

        # Service for manual control (optional)
        self.service = rospy.Service(
            '/lite3/command_vel',
            CommandVel,
            self.handle_service
        )

        rospy.loginfo("Path executor ready")

    def path_callback(self, msg):
        """Store the latest path from move_base"""
        self.current_path = msg
        rospy.loginfo(f"Received new path with {len(msg.poses)} points")

    def get_robot_pose(self):
        """Get current robot pose via TF"""
        try:
            (trans, rot) = self.tf_listener.lookupTransform(
                self.world_frame,
                self.robot_frame,
                rospy.Time(0))
            pose = PoseStamped()
            pose.pose.position.x = trans[0]
            pose.pose.position.y = trans[1]
            pose.pose.orientation.x = rot[0]
            pose.pose.orientation.y = rot[1]
            pose.pose.orientation.z = rot[2]
            pose.pose.orientation.w = rot[3]
            return pose
        except Exception as e:
            rospy.logwarn(f"TF error: {str(e)}")
            return None

    def control_loop(self, event):
        """Main control loop running at fixed frequency"""
        if self.current_path is None or len(self.current_path.poses) < 3:
            return

        robot_pose = self.get_robot_pose()
        if robot_pose is None:
            return

        # Find lookahead point
        lookahead_point = self.find_lookahead_point(robot_pose)
        
        # Calculate velocities
        linear, angular = self.calculate_controls(robot_pose, lookahead_point)
        
        # Send to robot
        self.send_udp_command(linear, angular)

    def find_lookahead_point(self, robot_pose):
        """Find the target point on path"""
        closest_dist = float('inf')
        lookahead_idx = 0

        for i, path_pose in enumerate(self.current_path.poses):
            dx = path_pose.pose.position.x - robot_pose.pose.position.x
            dy = path_pose.pose.position.y - robot_pose.pose.position.y
            distance = math.sqrt(dx**2 + dy**2)

            if distance < closest_dist:
                closest_dist = distance
                closest_idx = i

        # Find point lookahead_distance ahead
        target_idx = closest_idx
        total_dist = 0

        while target_idx < len(self.current_path.poses) - 1 and total_dist < self.lookahead_distance:
            p1 = self.current_path.poses[target_idx]
            p2 = self.current_path.poses[target_idx + 1]
            total_dist += math.sqrt(
                (p2.pose.position.x - p1.pose.position.x)**2 +
                (p2.pose.position.y - p1.pose.position.y)**2)
            target_idx += 1

        return self.current_path.poses[min(target_idx, len(self.current_path.poses) - 1)]

    def calculate_controls(self, robot_pose, target_pose):
        """Pure Pursuit control law"""
        # Transform target to robot frame
        try:
            target_in_robot = self.tf_listener.transformPose(
                self.robot_frame,
                target_pose)
        except Exception as e:
            rospy.logwarn(f"Transform failed: {str(e)}")
            return 0.0, 0.0

        # Calculate curvature
        x = target_in_robot.pose.position.x
        y = target_in_robot.pose.position.y
        curvature = 2.0 * y / (x**2 + y**2)

        # Calculate velocities
        linear = min(self.max_linear_speed, 0.5)  # Cap forward speed
        angular = curvature * linear

        # Apply angular limits
        angular = max(min(angular, self.max_angular_speed), -self.max_angular_speed)

        return linear, angular

    def send_udp_command(self, linear, angular):
        """Your working UDP command sender"""
        try:
            # Angular (0x0141)
            ang_cmd = struct.pack('<IIId', 0x0141, 8, 1, angular)
            self.sock.sendto(ang_cmd, (self.UDP_IP, self.UDP_PORT))
            
            # Linear (0x0140)
            lin_cmd = struct.pack('<IIId', 0x0140, 8, 1, linear)
            self.sock.sendto(lin_cmd, (self.UDP_IP, self.UDP_PORT))
            
            rospy.logdebug(f"Sent command: lin={linear:.2f}, ang={angular:.2f}")
        except Exception as e:
            rospy.logerr(f"UDP send failed: {str(e)}")

    def handle_service(self, req):
        """Service handler for manual control"""
        try:
            self.send_udp_command(req.linear_x, req.angular_z)
            return CommandVelResponse(True, "Manual command executed")
        except Exception as e:
            return CommandVelResponse(False, str(e))

if __name__ == '__main__':
    try:
        PathExecutor()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass