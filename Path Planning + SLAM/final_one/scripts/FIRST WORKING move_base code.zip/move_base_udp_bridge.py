#!/usr/bin/env python3
import rospy
import socket
import struct
from nav_msgs.msg import Path, Odometry
from geometry_msgs.msg import PoseStamped, Twist
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import actionlib
import math

class PathFollower:
    def __init__(self):
        rospy.init_node('path_follower')

        # UDP Configuration
        self.UDP_IP = rospy.get_param("~ip", "192.168.1.120")
        self.UDP_PORT = rospy.get_param("~port", 43893)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Path tracking
        self.current_path = None
        self.path_sub = rospy.Subscriber(
            '/move_base/NavfnROS/plan',
            Path,
            self.path_callback,
            queue_size=1,
            buff_size=2**24
        )

        # Publisher for move_base_simple/goal
        self.goal_pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)

        # Subscriber for robot's current pose (Odometry)
        self.odometry_sub = rospy.Subscriber('/rtabmap/odom', Odometry, self.odometry_callback)

        # Current robot pose (initialized to zero)
        self.current_pose = None

        rospy.loginfo("🚀 Path follower ready (publishing goal to /move_base_simple/goal)")

    def path_callback(self, msg):
        """Send the final waypoint of the received path to move_base."""
        if len(msg.poses) < 2:
            rospy.logwarn("⚠ Empty path received")
            return

        self.current_path = msg
        goal_pose = msg.poses[-1]  # Get the last point in the path
        rospy.loginfo(f"🎯 Sending goal to move_base: x={goal_pose.pose.position.x:.2f}, y={goal_pose.pose.position.y:.2f}")
        
        # Create a PoseStamped message to send the goal
        goal = PoseStamped()
        goal.header.frame_id = "map"  # Change to "odom" if needed
        goal.header.stamp = rospy.Time.now()
        goal.pose = goal_pose.pose

        # Publish the goal to /move_base_simple/goal
        self.goal_pub.publish(goal)
        rospy.loginfo("✅ Goal published to /move_base_simple/goal")

        # Call method to send UDP commands for motion
        self.move_to_goal(goal_pose.pose)

    def move_to_goal(self, goal_pose):
        """Move robot by calculating linear and angular velocity and sending UDP commands."""
        if not self.current_pose:
            rospy.logwarn("⚠ Current pose is not available yet!")
            return

        # Calculate linear and angular velocities
        linear, angular = self.calculate_velocities(goal_pose)

        # Send the calculated velocities via UDP
        self.send_udp_command(linear, angular)

    def calculate_velocities(self, goal_pose):
        """Calculate the required velocities to move towards the goal."""
        if not self.current_pose:
            return 0, 0

        # Extract current and goal positions
        current_x = self.current_pose.pose.pose.position.x
        current_y = self.current_pose.pose.pose.position.y
        goal_x = goal_pose.position.x
        goal_y = goal_pose.position.y

        # Calculate the difference in position
        dx = goal_x - current_x
        dy = goal_y - current_y

        # Calculate the angle to the goal
        angle_to_goal = math.atan2(dy, dx)

        # Calculate the distance to the goal
        distance_to_goal = math.sqrt(dx**2 + dy**2)

        # Control parameters (tune for your robot)
        linear_speed = 0.5  # meters per second
        angular_speed = 1.0  # radians per second

        # Linear velocity is proportional to the distance to the goal
        linear_velocity = min(linear_speed, distance_to_goal)

        # Angular velocity is proportional to the angle difference to the goal
        angular_velocity = min(angular_speed, angle_to_goal - self.current_pose.pose.pose.orientation.z)

        return linear_velocity, angular_velocity

    def send_udp_command(self, linear, angular):
        """Send command to robot over UDP."""
        try:
            # Angular (0x0141)
            ang_cmd = struct.pack('<IIId', 0x0141, 8, 1, angular)
            self.sock.sendto(ang_cmd, (self.UDP_IP, self.UDP_PORT))
            
            # Linear (0x0140)
            lin_cmd = struct.pack('<IIId', 0x0140, 8, 1, linear)
            self.sock.sendto(lin_cmd, (self.UDP_IP, self.UDP_PORT))
            
            rospy.logdebug(f"📤 Sent command: lin={linear:.2f}, ang={angular:.2f}")
        except Exception as e:
            rospy.logerr(f"❌ UDP send failed: {str(e)}")

    def odometry_callback(self, msg):
        """Store the current odometry information."""
        self.current_pose = msg

if __name__ == '__main__':
    try:
        PathFollower()
        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("Node shutdown")
