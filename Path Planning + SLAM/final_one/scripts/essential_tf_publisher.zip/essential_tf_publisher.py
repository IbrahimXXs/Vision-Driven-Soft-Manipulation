#!/usr/bin/env python3
import rospy
import tf2_ros
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped

class EssentialTFPublisher:
    def __init__(self):
        rospy.init_node('essential_tf_publisher')
        
        # Enable simulation time if needed
        self.use_sim_time = rospy.get_param('/use_sim_time', False)
        
        # TF Broadcaster
        self.tf_broadcaster = tf2_ros.TransformBroadcaster()
        
        # Initialize transforms
        self.map_to_odom = TransformStamped()
        self.map_to_odom.header.frame_id = "map"
        self.map_to_odom.child_frame_id = "odom"
        
        self.odom_to_base = TransformStamped()
        self.odom_to_base.header.frame_id = "odom"
        self.odom_to_base.child_frame_id = "base_link"
        self.odom_to_base.transform.rotation.w = 1.0  # Identity rotation
        
        # Subscribe to RTAB-Map odometry
        rospy.Subscriber('/rtabmap/odom', Odometry, self.odom_callback)
        
        # Publish rate (adjust as needed)
        self.rate = rospy.Rate(40)  # 40Hz
        rospy.loginfo("Essential TF publisher ready")

    def odom_callback(self, msg):
        # Update map->odom transform from RTAB-Map odometry
        self.map_to_odom.transform.translation.x = msg.pose.pose.position.x
        self.map_to_odom.transform.translation.y = msg.pose.pose.position.y
        self.map_to_odom.transform.translation.z = msg.pose.pose.position.z
        self.map_to_odom.transform.rotation = msg.pose.pose.orientation

    def run(self):
        while not rospy.is_shutdown():
            # Get current time (respects /use_sim_time)
            current_time = rospy.Time.now()
            
            # Update timestamps
            self.map_to_odom.header.stamp = current_time
            self.odom_to_base.header.stamp = current_time
            
            # Publish both transforms
            self.tf_broadcaster.sendTransform([
                self.map_to_odom,
                self.odom_to_base
            ])
            
            self.rate.sleep()

if __name__ == '__main__':
    try:
        publisher = EssentialTFPublisher()
        publisher.run()
    except rospy.ROSInterruptException:
        pass