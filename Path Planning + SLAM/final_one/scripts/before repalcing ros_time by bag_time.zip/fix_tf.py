#!/usr/bin/env python3
import rospy
import tf2_ros
from geometry_msgs.msg import TransformStamped
from tf.transformations import quaternion_from_euler

class StaticTFPublisher:
    def __init__(self):
        rospy.init_node('static_tf_publisher_40hz')
        
        # TF Broadcaster
        self.broadcaster = tf2_ros.TransformBroadcaster()
        
        # Define the three transforms you want
        self.transforms = [
            self.create_transform(
                parent="base_link",
                child="camera_link",
                translation=(0.2, 0, 0.2),
                rotation=(0, 0.3235, 0)  # Roll, Pitch, Yaw in radians
            ),
            self.create_transform(
                parent="base_link",
                child="camera_color_optical_frame",
                translation=(0.2, 0, 0.2),
                rotation=(0, 0.3235, 0)
            ),
            self.create_transform(
                parent="base_link",
                child="imu",
                translation=(0, 0, 0),
                rotation=(0, 0, 0)
            )
        ]
        
        # 40Hz publishing rate
        self.rate = rospy.Rate(40)
        rospy.loginfo("Publishing 3 static TFs at 40Hz")

    def create_transform(self, parent, child, translation, rotation):
        """Helper to create TransformStamped messages"""
        t = TransformStamped()
        t.header.frame_id = parent
        t.child_frame_id = child
        t.transform.translation.x = translation[0]
        t.transform.translation.y = translation[1]
        t.transform.translation.z = translation[2]
        
        # Convert RPY to quaternion
        q = quaternion_from_euler(rotation[0], rotation[1], rotation[2])
        t.transform.rotation.x = q[0]
        t.transform.rotation.y = q[1]
        t.transform.rotation.z = q[2]
        t.transform.rotation.w = q[3]
        return t

    def run(self):
        while not rospy.is_shutdown():
            # Update timestamps
            current_time = rospy.Time.now()
            for transform in self.transforms:
                transform.header.stamp = current_time
            
            # Publish all three transforms
            self.broadcaster.sendTransform(self.transforms)
            self.rate.sleep()

if __name__ == '__main__':
    try:
        publisher = StaticTFPublisher()
        publisher.run()
    except rospy.ROSInterruptException:
        pass