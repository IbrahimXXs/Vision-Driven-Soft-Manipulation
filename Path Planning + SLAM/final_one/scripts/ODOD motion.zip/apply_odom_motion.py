#!/usr/bin/env python3
import time
import math
import socket
import struct
import rospy
from nav_msgs.msg import Odometry
import tf.transformations as tf_trans

class RobotController:
    def __init__(self):
        rospy.init_node('robot_controller', anonymous=True)
        self.UDP_IP = "192.168.1.120"  # Replace with your robot's IP
        self.UDP_PORT = 43893
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.current_pose = (0.0, 0.0, 0.0)  # (x, y, theta)

        # Subscribe to /rtabmap/odom topic
        rospy.Subscriber("/rtabmap/odom", Odometry, self.odom_callback)
        rospy.loginfo("[INIT] Robot Controller Initialized")

    def odom_callback(self, msg):
        """Callback function to update the current pose from odometry data"""
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y

        # Extract yaw (theta) from quaternion
        orientation_q = msg.pose.pose.orientation
        _, _, theta = tf_trans.euler_from_quaternion([
            orientation_q.x,
            orientation_q.y,
            orientation_q.z,
            orientation_q.w
        ])

        self.current_pose = (x, y, theta)
        rospy.loginfo(f"[ODOM] Updated Pose: x={x:.3f}, y={y:.3f}, theta={theta:.3f}")

    def get_current_pose(self):
        """Fetch the latest odometry values"""
        return self.current_pose  

    def send_udp_command(self, linear, angular):
        """Send velocity commands via UDP"""
        rospy.loginfo(f"[UDP] Sending Linear={linear:.3f}, Angular={angular:.3f}")
        try:
            ang_cmd = struct.pack('<IIId', 0x0141, 8, 1, angular)
            self.sock.sendto(ang_cmd, (self.UDP_IP, self.UDP_PORT))
            
            lin_cmd = struct.pack('<IIId', 0x0140, 8, 1, linear)
            self.sock.sendto(lin_cmd, (self.UDP_IP, self.UDP_PORT))
        except Exception as e:
            rospy.logerr(f"❌ UDP send failed: {str(e)}")

    def rotate_to_angle(self, target_theta, speed=0.1):
        """Rotate the robot until it reaches the target angle"""
        rospy.loginfo(f"[ROTATE] Rotating to {target_theta:.3f} radians")
        while not rospy.is_shutdown():
            x, y, theta = self.get_current_pose()
            angle_diff = (target_theta - theta + math.pi) % (2 * math.pi) - math.pi
            rospy.loginfo(f"[current Angle] : {theta:.3f}")
            rospy.loginfo(f"[goal Angle] : {target_theta:.3f}")

            rospy.loginfo(f"[ROTATE] Angle diff: {angle_diff:.3f}")
            if abs(angle_diff) < 0.1:  # Stop when close enough
                self.send_udp_command(0, 0)
                break
            
            angular_speed = speed if angle_diff > 0 else -speed
            self.send_udp_command(0, angular_speed)
            rospy.sleep(0.1)

    def move_forward(self, distance, speed=0.2):
        """Move the robot forward by a given distance"""
        x_start, y_start, _ = self.get_current_pose()
        rospy.loginfo(f"[MOVE] Moving forward {distance:.3f} meters")

        while not rospy.is_shutdown():
            x, y, _ = self.get_current_pose()
            traveled_distance = math.sqrt((x - x_start)**2 + (y - y_start)**2)
            rospy.loginfo(f"[MOVE] Traveled: {traveled_distance:.3f} meters")

            if traveled_distance >= distance:
                self.send_udp_command(0, 0)
                break

            self.send_udp_command(speed, 0)
            rospy.sleep(0.1)

    def execute_motion(self, start_pose, goal_pose):
        """Apply the three motion steps"""
        x, y, theta = start_pose
        x_goal, y_goal, theta_goal = goal_pose
        
        rospy.loginfo("[EXECUTE] Motion Execution Started")
        
        # Compute motion parameters
        delta_rot1 = math.atan2(y_goal - y, x_goal - x) - theta
        delta_trans = math.sqrt((x_goal - x)**2 + (y_goal - y)**2)
        delta_rot2 = theta_goal - theta - delta_rot1

        rospy.loginfo(f"[EXECUTE] delta_rot1: {delta_rot1:.3f}, delta_trans: {delta_trans:.3f}, delta_rot2: {delta_rot2:.3f}")

        # Step 1: Rotate to face goal
        target_theta = theta + delta_rot1
        self.rotate_to_angle(target_theta)

        # Step 2: Move forward
        self.move_forward(delta_trans)

        # Step 3: Final rotation
        target_theta = theta_goal
        self.rotate_to_angle(target_theta)

        rospy.loginfo("[EXECUTE] Motion Execution Completed")

if __name__ == "__main__":
    controller = RobotController()
    rospy.sleep(1)  # Wait for the first odometry message

    start_pose = controller.get_current_pose()
    rospy.loginfo(f"[MAIN] Start Pose: {start_pose}")
    
    goal_pose = (1, 1, math.pi / 2)  # Move to (1,1) and face upward
    rospy.loginfo(f"[MAIN] Goal Pose: {goal_pose}")
    
    controller.execute_motion(start_pose, goal_pose)
