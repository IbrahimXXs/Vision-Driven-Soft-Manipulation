#!/usr/bin/env python3
import rospy
import struct
import socket
from geometry_msgs.msg import Twist

class CmdVelToUDP:
    def __init__(self):
        rospy.init_node("cmd_vel_to_udp", anonymous=True)

        # UDP Configuration
        self.UDP_IP = "192.168.1.100"  # Replace with your robot's IP
        self.UDP_PORT = 5005           # Replace with your robot's UDP port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Subscribe to /cmd_vel
        rospy.Subscriber("/cmd_vel", Twist, self.cmd_vel_callback)
        rospy.loginfo("🟢 Listening to /cmd_vel and forwarding to UDP...")

    def cmd_vel_callback(self, msg):
        """Convert /cmd_vel to UDP commands"""
        linear = msg.linear.x
        angular = msg.angular.z
        self.send_udp_command(linear, angular)

    def send_udp_command(self, linear, angular):
        """Send command to robot via UDP"""
        try:
            # Angular (0x0141)
            ang_cmd = struct.pack('<IIId', 0x0141, 8, 1, angular)
            self.sock.sendto(ang_cmd, (self.UDP_IP, self.UDP_PORT))
            
            # Linear (0x0140)
            lin_cmd = struct.pack('<IIId', 0x0140, 8, 1, linear)
            self.sock.sendto(lin_cmd, (self.UDP_IP, self.UDP_PORT))
            
            rospy.loginfo(f"📤 Sent command: lin={linear:.2f}, ang={angular:.2f}")
        except Exception as e:
            rospy.logerr(f"❌ UDP send failed: {str(e)}")

if __name__ == "__main__":
    try:
        CmdVelToUDP()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
